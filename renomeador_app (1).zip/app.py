
import streamlit as st
import pytesseract
from pdf2image import convert_from_bytes
import zipfile
import io

st.set_page_config(page_title="Renomeador Inteligente", layout="centered")

st.title("📂 Renomeador Inteligente de Documentos")

uploaded_files = st.file_uploader("Envie os PDFs", type="pdf", accept_multiple_files=True)

def extrair_nome(texto):
    linhas = texto.split("\n")
    for linha in linhas:
        if "nome" in linha.lower():
            return linha.split(":")[-1].strip()
    return "Sem Nome"

def identificar_documento(texto):
    t = texto.lower()
    if "folha de pagamento" in t:
        return "Folha de Pagamento"
    elif "comprovante" in t:
        return "Comprovante"
    elif "holerite" in t:
        return "Holerite"
    else:
        return "Documento"

if uploaded_files:
    if st.button("🚀 Processar arquivos"):
        zip_buffer = io.BytesIO()
        zip_file = zipfile.ZipFile(zip_buffer, "a")

        for file in uploaded_files:
            images = convert_from_bytes(file.read())

            texto_total = ""
            for img in images:
                texto_total += pytesseract.image_to_string(img)

            nome = extrair_nome(texto_total)
            tipo = identificar_documento(texto_total)

            novo_nome = f"{nome} - {tipo}.pdf"
            zip_file.writestr(novo_nome, file.getvalue())

        zip_file.close()

        st.success("Arquivos processados com sucesso!")

        st.download_button(
            label="📥 Baixar arquivos renomeados",
            data=zip_buffer.getvalue(),
            file_name="documentos_renomeados.zip",
            mime="application/zip"
        )
