
PASSO A PASSO (SUPER SIMPLES)

1) Instale o Python:
https://www.python.org/downloads/

2) Instale as bibliotecas (abra o CMD):
pip install streamlit pytesseract pdf2image pillow

3) Instale o Tesseract OCR:
https://github.com/tesseract-ocr/tesseract

4) Rode o sistema:
streamlit run app.py

5) Vai abrir no navegador:
- Envie os PDFs
- Clique em "Processar"
- Baixe os arquivos renomeados

PRONTO 🚀
